'''
Created on 20 feb 2018

@author: lorenzo
'''

class TextAnnotator:
    '''
    Takes Text and Return AnnotatedObject
    '''
    

    def __init__(self):
        '''
        Constructor
        '''
        raise Exception("Not implemented")

    
    def annotate(self,textObj):
        '''
        not implemented
        '''
        raise Exception("Not implemented: annotate")